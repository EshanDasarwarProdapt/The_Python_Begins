"""
Core package initialization.
"""
