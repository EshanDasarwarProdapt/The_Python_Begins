"""
Models package initialization.
"""
