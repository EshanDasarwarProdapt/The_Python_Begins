"""
API package initialization.
"""
